

# IMPORTANT NOTES -----------------------------


# for interactive Sherlock:
# path = "/home/groups/manishad/IAI"; setwd(path); source("doParallel_IAI.R")


# because Sherlock 2.0 restores previous workspace
rm( list = ls() )


# are we running locally?
run.local = FALSE
# run.local = TRUE

# should we set scen params interactively on cluster?
# *if you accidently set this to TRUE and run via sbatches on cluster,
#   they will all run the same scenario! 
interactive.cluster.run = FALSE

# should lots of output be printed for each sim rep?
verbose = TRUE

# ~~ Packages -----------------------------------------------
toLoad = c("crayon",
           "dplyr",
           "foreach",
           "doParallel",
           "data.table",
           "purrr",
           "tidyr",
           "tibble",
           "testthat",
           #"Hmisc",
           "stringr",
           "mice",
           "Amelia",
           "R2jags",  # only needed if running method IPW-nm. If removing, you can also remove "module load openblas/0.3.20" and "module load jags/4.3.1" from genSbatch.
           "geepack", # also only for IPW-nm
           "mix", # only for genloc imputation
           "boot", # for parametric AF4
           "MASS",
           "miapack",
           "tmle")

if ( run.local == TRUE | interactive.cluster.run == TRUE ) toLoad = c(toLoad, "here")

# dev version of miapack
#library(remotes)
#remotes::install_github("stmcg/miapack", ref = "ice-implementation")
#library(miapack)


# SET UP FOR CLUSTER OR LOCAL RUN ------------------------------

# ~~ Cluster Run ----------------------------------------
if (run.local == FALSE ) {
  
  # load command line arguments
  args = commandArgs(trailingOnly = TRUE)
  
  cat("\n\n args received from sbatch file:", args)
  
  jobname = args[1]
  scen = args[2]  # this will be a number
  n.reps.in.doParallel = args[3]
  
  # load packages with informative messages if one can't be installed
  # **Common reason to get the "could not library" error: You did ml load R/XXX using an old version
  any.failed = FALSE
  for (pkg in toLoad) {
    
    cat( paste("\nAbout to try loading package", pkg) )
    
    tryCatch({
      # eval below needed because library() will otherwise be confused
      # https://www.mitchelloharawild.com/blog/loading-r-packages-in-a-loop/
      eval( bquote( library( .(pkg) ) ) )
    }, error = function(err) {
      cat( paste("\n*** COULD NOT LOAD PACKAGE:", pkg) )
      any.failed <<- TRUE
    })
    
  }
  if ( any.failed == TRUE ) stop("Some packages couldn't be loaded. See outfile for details of which ones.")
  
  select = dplyr::select
  
  # helper code
  path = "/home/groups/manishad/IAI"
  setwd(path)
  source("helper_IAI.R")
  
  
  # get scen parameters (made by genSbatch.R)
  setwd(path)
  scen.params = read.csv( "scen_params.csv" )
  p <<- scen.params[ scen.params$scen == scen, ]
  
  cat("\n\nHEAD OF ENTIRE SCEN.PARAMS:\n")
  print(p)
  
  # set the number of cores
  registerDoParallel(cores=16)
  
}


# FOR LOCAL USE  ------------------------------
if ( run.local == TRUE ) {
  
  lapply( toLoad,
          require,
          character.only = TRUE)
  
  select = dplyr::select
  
  # helper fns
  code.dir = here()
  setwd(code.dir)
  source("helper_IAI.R")
  
  # for saving intermediate results
  data.dir = str_replace( string = here(),
                          pattern = "Simulation code",
                          replacement = "Simulation results" )
  
  
  # ~~ ********** Set Sim Params: Local Run -----------------------------
  
  scen.params = tidyr::expand_grid(
    
    #rep.methods = "gold ; CC ; mia-pkg-sp ; mia-pkg-ice ; mia-tmle", 
    rep.methods = "gold ; mia-pkg-ice ; mia-tmle ; IPW-nm",
    #rep.methods = "mia-pkg-ice",
    
    model = "OLS", 
    coef_of_interest = "A",
    N = c(1000),
    
    # MICE parameters
    # as on cluster
    #imp_m = 5,  # CURRENTLY SET LOW
    imp_m = 50,
    imp_maxit = 100,
    mice_method = NA,  # let MICE use its defaults
    
    # AF4 parameters
    #boot_reps_mia_ice = 0,
    boot_reps_mia_ice = 1000,  # only needed for CIs; if set to 0, won't give CIs
    mia_n_mc = 10000, 
    
    # for mia_tmle
    calculate_tmle_CIs = TRUE,
    
    dag_name = c("5A"),
    # 
    # dag_name = c("5D", "5D-bin",
    #              "6D", "6D-bin",
    #              "7D", "7D-bin"
    #              )  # make sure to pick appropriate outcome model for the DAG
    
    # dag_name = c("1A", "1B", "1C",
    #              "2A", "2B",
    #              "3A", "3B"),
    
    W_dim = 1
    #W_dim = c(1, 10)
    
  )
  
  # W-block parameters (constant across scens; edit here to vary) ----------
  scen.params = scen.params %>%
    mutate(
      W_n_cont          = ifelse( W_dim == 1, 0, 5 ),   # 5 continuous, 5 binary when W_dim = 10
      
      # W^+ / W^- split: complete vs incomplete components, type-balanced.
      # Set W_n_cont_complete = W_n_bin_complete = 0 for an all-incomplete arm.
      W_n_cont_complete = ifelse( W_dim == 1, 0, 3 ),
      W_n_bin_complete  = ifelse( W_dim == 1, 0, 2 ),
      
      W_rho             = ifelse( W_dim == 1, 0, 0.4 ),  # LATENT-scale correlation
      W_cor_type        = "exch",                        # "exch" or "ar1"
      W_bin_prob        = 0.5,                            # marginal P(W_binary = 1)
      
      # target marginal P(R_Wj = 0) for incomplete components. Legacy value is
      # 0.4252 (what expit(-1 + 3*D1) implies); fine at W_dim = 1 but leaves ~3.6%
      # complete cases at W_dim = 10, so the high-dim arms use 0.10.
      W_miss_rate       = ifelse( W_dim == 1, 1 - 0.5748, 0.10 ),
      
      # required by the W-block generator (their absence caused the crash):
      W_parent_coef     = 1,     # strength of the W parent (X2 or Y, per DAG) -> W
      W_n_inter         = 3,     # # of W_j*W_k interaction terms in S_R (needs 2*W_n_inter <= W_dim)
      W_inter_coef      = 1  # coefficient on each interaction term
    )
  
  
  # remove bad combos:
  # 5-series must have W_dim=1
  scen.params = scen.params %>% filter( !(dag_name %in% c("5A", "5B", "5C", "5D") & W_dim > 1 ) )
  # check it 
  table(scen.params$dag_name, scen.params$W_dim)
  
  # replace rep.methods string to not include IPW-nm when W_dim > 1
  rm_IPW_nm = function(string) paste(setdiff(strsplit(string, "\\s*;\\s*")[[1]], "IPW-nm"), collapse = " ; ")
  # example: rm_IPW_nm("gold ; CC ; mia-pkg-sp ; mia-pkg-ice ; IPW-nm")
  scen.params = scen.params %>% rowwise() %>%
    mutate( rep.methods = ifelse( W_dim > 1, rm_IPW_nm(rep.methods), rep.methods ) )
  

  start.at = 1  # scen name to start at
  scen.params$scen = start.at:( nrow(scen.params) + start.at - 1 )
  
  # set the number of local cores
  registerDoParallel(cores=8)
  
  scen = 1
  # data.frame(scen.params %>% filter(scen.name == scen))
  
  # just to avoid errors in doParallel script below
  jobname = "job_1"
  i = 1
}



# RUN SIMULATION ------------------------------


# mimic Sherlock structure
if (run.local == TRUE) ( scens_to_run = scen.params$scen )
if (run.local == FALSE) ( scens_to_run = scen )  # from sbatch
if (run.local == TRUE) n.reps.in.doParallel = 1
if ( exists("rs_all_scens") ) rm(rs_all_scens)
#  p = scen.params[ scen.params$scen == scen, names(scen.params) != "scen"]


# BEGIN FOR-LOOP to run multiple scens locally
# if running on cluster, scen will just be length 1


for ( scen in scens_to_run ) {
  
  if ( exists("rs") ) rm(rs)
  if ( exists("rep.res") ) rm(rep.res)
  
  # doParallel handles ONE scen at a time
  # system.time is in seconds
  # ~ ********** Beginning of ForEach Loop -----------------------------
  doParallel.seconds = system.time({
    
    rs = foreach( i = 1:n.reps.in.doParallel, .combine = bind_rows ) %dopar% {
      #for debugging (out file will contain all printed things):
      #for ( i in 1:sim.reps ) {
      
      # only print info for first sim rep for visual clarity
      if ( i == 1 ) cat("\n\n~~~~~~~~~~~~~~~~ BEGIN SIM REP", i, "~~~~~~~~~~~~~~~~")
      
      # results for just this simulation rep
      if ( exists("rep.res") ) suppressWarnings( rm(rep.res) )
      
      # for debugging
      if ( TRUE ) {
        cat("\n\n scen variable:\n")
        print(scen)
        
        cat("\n\n scen.params again:\n")
        print(scen.params)
      }
      
      p = scen.params[ scen.params$scen == scen, names(scen.params) != "scen"]
      coef_of_interest = p$coef_of_interest
      
      # show beginning of dataset
      #if ( i == 1 & verbose == TRUE) cat("\n\nDIM AND HEAD OF P (SINGLE ROW OF SCEN.PARAMS):\n")
      
      # parse methods string
      ( all.methods = unlist( strsplit( x = p$rep.methods,
                                        split = " ; " ) ) )
      
      
      # ~ Simulate Dataset ------------------------------
      sim_obj = sim_data(.p = p)
      
      du = sim_obj$du
      di = sim_obj$di
      ( form_string = as.character( sim_obj$form_string ) )
      ( gold_form_string = as.character( sim_obj$gold_form_string ) )
      ( beta = as.numeric(sim_obj$beta) )
      ( exclude_from_imp_model = as.character( sim_obj$exclude_from_imp_model ) )
      

      # coefficient of interest for gold-standard model
      if ( coef_of_interest == "(Intercept)" ){
        coef_of_interest_gold = "(Intercept)"
        
      } else if ( coef_of_interest == "A:C" ){
        coef_of_interest_gold = "A1:C1"
      } else {
        # *this assumes coef_of_interest is always the factual variable
        #  (e.g., A), so need to add "1" to use the variable
        # that's in gold-standard model
        coef_of_interest_gold = paste(coef_of_interest, "1", sep = "")
      }
      
      
      # for debugging
      if ( TRUE ) {
        cat("\n\n doParallel flag: Done generating data\n")
      }
      
      
      # ~ Make Imputed Data ------------------------------
      
      
      # ~~ genloc: JM with general location model ----
      
      if ( "genloc" %in% all.methods & !is.null(di) ) {
        
        message("Starting to impute using genloc")
        
        # ensure all binary vars are factors; otherwise using methods
        #  other than pmm will treat them as continuous
        #di = convert_binary_to_factor(di)
        
        # mix needs: "data matrix containing missing values. The rows of x correspond to observational units, and the columns to variables.
        # Missing values are denoted by NA. The categorical variables must be in the first p columns of x,
        # and they must be coded with consecutive positive integers starting with 1.
        # For example, a binary variable must be coded as 1,2 rather than 0,1."
        # accordingly, recode the binaries and reorder columns.
        temp = recode_binaries(di)
        di2 = temp$df
        n_bin = temp$num_binaries
        
        
        
        if (n_bin == 0) {
          
          message("No binaries found — adding fake binary column for genloc compatibility")
          di2$z_fake <- sample(1:2, nrow(di2), replace = TRUE)  # coded 1/2 as mix requires
          n_bin <- 1
          # move fake binary to front (mix requires binaries in first p columns)
          di2 <- di2[ , c("z_fake", setdiff(names(di2), "z_fake")) ]
          added_fake <- "binary"
          
        } else if (n_bin == ncol(di2)) {
          
          message("All columns are binary — adding fake continuous column for genloc compatibility")
          di2$z_fake <- rnorm(nrow(di2))
          added_fake <- "continuous"
          
        } else {
          
          added_fake <- "none"
          
        }
        
        
        # this block sometimes throws "improper posterior -- empty cells"
        tryCatch({
          # randomize the random seed
          rngseed( runif(min = 1000000, max = 9999999, n=1) )
          
          # *** generate the imputations
          di3 <- prelim.mix(di2, p = n_bin)
          
          thetahat <- em.mix(di3)
          
          m <- p$imp_m  
          imps_genloc <- vector("list", m)
          
          # NB: this loop used to be indexed by `i`, which is ALSO the foreach
          # sim-rep index. It silently overwrote the rep counter, so every
          # rep.name downstream was recorded as imp_m rather than the rep.
          for (.imp in 1:m) {
            newtheta <- da.mix(di3, thetahat, steps = 100)
            newimp   <- as.data.frame( imp.mix(s = di3, theta = newtheta, x = di2) )
            newimp   <- reverse_recode_binaries(newimp)
            newimp$z_fake <- NULL          # <-- dropped from each imputed dataset before storing
            imps_genloc[[.imp]] <- newimp  # <-- stored without z_fake
          }
          
          # sanity check
          imp1 = imps_genloc[[1]]
          
          if ( any(is.na(imp1)) ) {
            message("MI left NAs in dataset - what a butt")
            imps_genloc = NULL
          } 
          
          
        }, error = function(e) {
          message("error making genloc imputations: ", e$message)
          # superassignment: the previous `imps_genloc = NULL` was local to the
          # handler and never reached the caller
          imps_genloc <<- NULL
          
          # save the problem dataset
          if (run.local == FALSE) {
            
            # for debugging
            setwd("/home/groups/manishad/IAI/rmfiles")
            fwrite( rs, paste( "rm_data", jobname, ".csv", sep="_" ) )
            
          }
        }
        )
        
        
        
        message("Done imputing using genloc")
        
        
      } else {
        imps_genloc = NULL
      }
      
      
      
      
      # ~~ MICE-std ----
      # details of how mice() implements pmm:
      # ?mice.impute.pmm
      if ( "MICE-std" %in% all.methods & !is.null(di) ) {
        
        
        message("Starting to impute using MICE-std")
        
        
        # ensure all binary vars are factors; otherwise using methods
        #  other than pmm will treat them as continuous
        di2 = convert_binary_to_factor(di)
        
        # only pass method arg if it's not NA or NULL
        if ( is.na(p$mice_method) | is.null(p$mice_method) ) {
          imps_mice_raw = mice( di2,
                                maxit = p$imp_maxit,
                                m = p$imp_m,
                                printFlag = FALSE )
          
          
          # reorganize the complicated mids object into list of imputed datasets
          # needed for fit_regression to find the imputed datasets
          imps_mice = lapply(seq_len(imps_mice_raw$m), function(i) complete(imps_mice_raw, i))
          
          # recode any 0/1 factors as numeric for regression joy
          imps_mice <- lapply(imps_mice, function(.d) 
            .d %>% mutate(across(where(is.factor), ~ as.numeric(as.character(.)))))
          
        } else {
          imps_mice_raw = mice( di2,
                                maxit = p$imp_maxit,
                                m = p$imp_m,
                                
                                # "A vector of length 4 containing the default imputation methods for 1) numeric data, 2) factor data with 2 levels, 3) factor data with > 2 unordered levels, and 4) factor data with > 2 ordered levels. By default, the method uses pmm, predictive mean matching (numeric data) logreg, logistic regression imputation (binary data, factor with 2 levels) polyreg, polytomous regression imputation for unordered categorical data (factor > 2 levels) polr, proportional odds model for (ordered, > 2 levels)."
                                # default for defaultMethod is: c("pmm", "logreg", "polyreg", "polr")
                                #defaultMethod = c("norm", "logreg", "polyreg", "polr"),
                                
                                method = p$mice_method,
                                printFlag = FALSE )
          
          # reorganize the complicated mids object into list of imputed datasets
          # needed for fit_regression to find the imputed datasets
          imps_mice = lapply(seq_len(imps_mice_raw$m), function(i) complete(imps_mice_raw, i))
          
          # recode any 0/1 factors as numeric for regression joy
          imps_mice <- lapply(imps_mice, function(.d) 
            .d %>% mutate(across(where(is.factor), ~ as.numeric(as.character(.)))))
        }
        
        
        
        # was imps_mice$method, but imps_mice is a plain list of completed
        # datasets -- the mids object is imps_mice_raw
        mice_std_methods = summarize_mice_methods(imps_mice_raw$method)
        
        # sanity check
        imp1 = imps_mice[[1]]
        
        if ( any(is.na(imp1)) ) {
          message("MI left NAs in dataset - what a butt")
          imps_mice = NULL
        }
        
        message("Done imputing using MICE-std")
        
        
      } else {
        imps_mice = NULL
      }
      
      
      # ~~ Am-std ----
      if ( "Am-std" %in% all.methods & !is.null(di) ) {
        
        imps_am_std = amelia( as.data.frame(di),
                              m=p$imp_m,
                              p2s = 0 # don't print output
        )
        
        
        imp1 = imps_am_std$imputations$imp1
        
        if ( any(is.na(imp1)) ) {
          message("MI left NAs in dataset - what a butt")
          imps_am_std = NULL
        }
        
        
      } else {
        imps_am_std = NULL
      }
      
      
      
      
      # ~ Initialize Global Vars ------------------------------
      
      # initialize rep.res st run_method_safe and other standalone estimation fns
      #  will correctly recognize it as having 0 rows
      rep.res = data.frame()
      
      
      # ~ Fit Models ------------------------------
      
      
      # ~~ Gold standard: No missing data ----
      if ( "gold" %in% all.methods ) {
        
        
        rep.res = run_method_safe(method.label = c("gold"),
                                  
                                  method.fn = function(x) fit_regression(form_string = gold_form_string,
                                                                         model = p$model,
                                                                         # *this assumes coef_of_interest is always the factual variable
                                                                         #  (e.g., A), so need to add "1" to use the variable
                                                                         # that's in gold-standard model
                                                                         coef_of_interest = coef_of_interest_gold,
                                                                         miss_method = "gold",
                                                                         du = du,
                                                                         imps = NULL),
                                  .rep.res = rep.res )
        
        if (run.local == TRUE) srr(rep.res)
      }
      
      
      
      
      # ~~ Complete-case analysis (naive) ----
      if ( "CC" %in% all.methods ) {
        
        message("Entered CC part")
        cat(str(di$B))
        cat(table(di$B, useNA = "ifany"))
        
        
        
        rep.res = run_method_safe(method.label = c("CC"),
                                  
                                  method.fn = function(x) fit_regression(form_string = form_string,
                                                                         model = p$model,
                                                                         # *this assumes coef_of_interest is always the factual variable
                                                                         #  (e.g., A), so need to add "1" to use the variable
                                                                         # that's in gold-standard model
                                                                         coef_of_interest = coef_of_interest,
                                                                         miss_method = "CC",
                                                                         du = di,
                                                                         imps = NULL),
                                  .rep.res = rep.res )
        
        if (run.local == TRUE) srr(rep.res)
      }
      
      
      
      
      
      
      
      
      # ~~ genloc ----
      if ( "genloc" %in% all.methods ) {
        rep.res = run_method_safe(method.label = c("genloc"),
                                  
                                  method.fn = function(x) fit_regression(form_string = form_string,
                                                                         model = p$model,
                                                                         coef_of_interest = coef_of_interest,
                                                                         miss_method = "MI",
                                                                         du = NULL,
                                                                         imps = imps_genloc),
                                  .rep.res = rep.res )
        
        if (run.local == TRUE) srr(rep.res)
      }
      
      
      
      
      
      
      
      # ~~ MICE-std ----
      if ( "MICE-std" %in% all.methods ) {
        rep.res = run_method_safe(method.label = c("MICE-std"),
                                  
                                  method.fn = function(x) fit_regression(form_string = form_string,
                                                                         model = p$model,
                                                                         coef_of_interest = coef_of_interest,
                                                                         miss_method = "MI",
                                                                         du = NULL,
                                                                         imps = imps_mice),
                                  .rep.res = rep.res )
        
        if (run.local == TRUE) srr(rep.res)
      }
      

      
      # ~~ Am-std ----
      if ( "Am-std" %in% all.methods & !is.null(imps_am_std) ) {
        rep.res = run_method_safe(method.label = c("Am-std"),
                                  
                                  method.fn = function(x) fit_regression(form_string = form_string,
                                                                         model = p$model,
                                                                         coef_of_interest = coef_of_interest,
                                                                         miss_method = "MI",
                                                                         du = NULL,
                                                                         imps = imps_am_std),
                                  .rep.res = rep.res )
        
        if (run.local == TRUE) srr(rep.res)
      }
      
 
      # ~~ IPW-nm ----
      # Sun & ETT
      if ( "IPW-nm" %in% all.methods ) {
        
        # #FOR DEBUGGING ONLY!!
        # cat("\n\n ~~~~~~~~~~~~~~~~~~~ About to run IPW-nm for sim rep", i)
        # # save the dataset locally
        # setwd("/Users/mmathur/Dropbox/Personal computer/Independent studies/*Inchoate/2024/2024-10-20 - IAI (Incomplete auxiliaries in imputation)/Simulation study/Results/temp debugging")
        # fwrite( du, file = paste("rep", i, ".csv") )
        
        rep.res = run_method_safe(method.label = c("IPW-nm"),
                                  
                                  method.fn = function(x) fit_regression(form_string = form_string,
                                                                         model = p$model,
                                                                         coef_of_interest = coef_of_interest,
                                                                         miss_method = "IPW-nm",
                                                                         du = du,
                                                                         imps = NULL),
                                  .rep.res = rep.res )
        
        
        cat("\n\n  ~~~~~~~~~~~~~~~~~~~ Done running IPW-nm for sim rep", i)
        
        if (run.local == TRUE) srr(rep.res)
        
      }
      
      # for debugging only
      # rep.res = data.frame()

      
      # ~~ MIA-SP package (semiparametric, using miapack) ----
      if ( "mia-pkg-sp" %in% all.methods ) {
        rep.res = run_method_safe(method.label = c("mia-pkg-sp"),
                                  
                                  method.fn = function(x) {
                           
                                    # parse the gold model into outcome + predictors
                                    fo        = as.formula(form_string)   # e.g. B ~ A * C
                                    outcome   = all.vars(fo)[1]           # LHS, e.g. "B"
                                    exposure  = coef_of_interest          # e.g. "A"
                                    rhs_vars  = all.vars(fo)[-1]          # main-effect vars on RHS
                                    covars    = setdiff(rhs_vars, exposure)  # analysis covars X \ exposure
                                    
                                    Wobs   = w_names(p)$obs               # W component columns
                                    X_names = c(exposure, covars)         # predictor set for mia()
                                    
                                    # miapack::mia REQUIRES the outcome column to be named "Y"
                                    # (see ?mia / dat.sim). Rename on a local copy only; predictors
                                    # keep their real names and are referenced via X_names.
                                    di_mia = di
                                    names(di_mia)[names(di_mia) == outcome] = "Y"
                                    
                                    # rebuild the outcome-model formula with LHS "Y", same RHS
                                    # terms as the gold model (keeps interactions) plus W
                                    rhs_terms = labels(terms(fo))         # e.g. "A","C","A:C"
                                    

                                    # rebuild the outcome-model formula with LHS "Y", same RHS
                                    # terms as the gold model (keeps interactions), FULLY CROSSED
                                    # with the W block. 
                                    # ***Note: It's very important to include all C-W interactions since some DAGs, e.g., 1A, include
                                    #  those interactions! HOWEVER, the code below does NOT include W-W interactions, which matches
                                    #  all DAGs' DGMs as of 2026-07-22.
                                    rhs_terms = labels(terms(fo))         # e.g. "A","C","A:C"
                                    
                                    # X-part: the gold model's RHS as a single grouped term,
                                    # e.g. "(A + C + A:C)". Falls back to intercept-only if the
                                    # gold model has no RHS terms.
                                    x_part = if (length(rhs_terms) > 0)
                                      paste0("(", paste(rhs_terms, collapse = " + "), ")") else "1"
                                    
                                    # W-part: all observed W components as a single grouped term,
                                    # e.g. "(W01)" for |W|=1 or "(W1 + W2 + ... )" for a W block.
                                    w_part = paste0("(", paste(Wobs, collapse = " + "), ")")
                                    
                                    # Full cross: Y ~ (X terms) * (W terms). The "*" expands to all
                                    # main effects plus every X:W interaction (and X:X, W:W within
                                    # each group as already implied by rhs_terms / additive W).
                                    Y_form = as.formula(paste0("Y ~ ", x_part, " * ", w_part))
                                    # end of building the outcome-model formula
                                    
                                    # contrast: exposure 1 vs 0, all covars held at reference level 0
                                    ref = rep(0, length(covars))
                                    Xv1 = c(1, ref)
                                    Xv0 = c(0, ref)
                                    
                                    # types, aligned to how sim_data builds the columns 
                                    Y_type = if ( p$model == "logistic" ) "binary" else "continuous"
                                    W_type = ifelse( seq_along(Wobs) <= p$W_n_cont, "normal", "binary" )
                                    
                                    # one W-model per component (sequential factorization):
                                    #      w_j ~ exposure + covars + earlier components
                                    W_forms = lapply( seq_along(Wobs), function(j) {
                                      preds = c(X_names, Wobs[seq_len(j - 1)])
                                      as.formula( paste(Wobs[j], "~", paste(preds, collapse = " + ")) )
                                    })
                                    
                                    mia_args = list(
                                      data          = di_mia,
                                      X_names       = X_names,
                                      X_values_1    = Xv1,
                                      X_values_2    = Xv0,
                                      contrast_type = "difference",
                                      Y_model       = Y_form,
                                      Y_type        = Y_type,
                                      W_model       = W_forms,
                                      W_type        = W_type,
                                      n_mc          = p$mia_n_mc
                                    )
                                    
                                    fit = do.call(miapack::mia, mia_args)
                                    
                                    # point estimate = the exposure 1 vs 0 contrast
                                    # inthat = reference-level mean E0 (exposure 0, covars 0),
                                    # i.e. fit$mean_est_2 -- the "(Intercept)"-analogue level.
                                    if ( p$boot_reps_mia_ice == 0 ) {
                                      return( list( stats = data.frame(
                                        bhat   = fit$contrast_est,
                                        inthat = fit$mean_est_2
                                      ) ) )
                                    }
                                    
                                    # bootstrap CI via miapack::get_CI 
                                    # get_CI takes the FITTED mia object (not the modeling args)
                                    # and wraps boot / boot.ci. type = "bca" is the mia default.
                                    ci_obj = miapack::get_CI(
                                      mia_res = fit,
                                      n_boot  = p$boot_reps_mia_ice,
                                      type    = "bca",   
                                      conf    = 0.95
                                    )
                                    
                                    bhat_ci_row = ci_obj$ci_contrast[[4]]
                                    bhat_ci_lo  = bhat_ci_row[ length(bhat_ci_row) - 1 ]
                                    bhat_ci_hi  = bhat_ci_row[ length(bhat_ci_row) ]
                                    
                                    inthat_ci_row = ci_obj$ci_2[[4]]  # ci_2 because inthat = mean_est_2 (all predictors 0)
                                    inthat_ci_lo  = inthat_ci_row[ length(inthat_ci_row) - 1 ]
                                    inthat_ci_hi  = inthat_ci_row[ length(inthat_ci_row) ]
                                    
                                    return( list( stats = data.frame(
                                      bhat       = fit$contrast_est,
                                      bhat_lo    = bhat_ci_lo,
                                      bhat_hi    = bhat_ci_hi,
                                      bhat_width = bhat_ci_hi - bhat_ci_lo,
                                      
                                      inthat    = fit$mean_est_2,
                                      int_lo    = inthat_ci_lo,
                                      int_hi    = inthat_ci_hi,
                                      int_width = inthat_ci_hi - inthat_ci_lo
                                    ) ) )
                                  },
                                  .rep.res = rep.res )
        
        if (run.local == TRUE) srr(rep.res)
      }
      
      # FOR DEBUGGING
      cat("\n rep.res after running mia-pkg-sp")
      if (exists("rep.res")) srr(rep.res)
      
      # ~~ MIA-ICE (iterative conditional expectation, using miapack) --------------
      # miapack::mia_ice (ice-implementation branch): plug-in estimator of
      #   mu_MIA(x) = E[ E[Y | X=x, W, M=1] | X=x, R_W=R_X=1 ].
      # Differs from the Monte Carlo mia(): no W-density model and no n_mc.
      # Instead it fits the outcome model, predicts g_hat = Ehat[Y|x,W,M=1] at
      # the target x, then regresses g_hat on X via `outer_model` (LHS must be
      # g_hat; RHS may reference ONLY the X predictors). Saturating outer_model
      # in X reduces mu_MIA(x) to the sample mean of g_hat within each X cell.
      #
      # Everything DAG-specific is parsed from sim_obj$form_string +
      # coef_of_interest + w_names(p); nothing is hard-coded.
      if ( "mia-pkg-ice" %in% all.methods ) {
        rep.res = run_method_safe(method.label = c("mia-pkg-ice"),
                                  
                                  method.fn = function(x) {

                                    
                                    # parse the gold model into outcome + predictors
                                    fo        = as.formula(form_string)   # e.g. B ~ A * C
                                    outcome   = all.vars(fo)[1]           # LHS, e.g. "B"
                                    exposure  = coef_of_interest          # e.g. "A"
                                    rhs_vars  = all.vars(fo)[-1]          # main-effect vars on RHS
                                    covars    = setdiff(rhs_vars, exposure)  # analysis covars X \ exposure
                                    
                                    Wobs   = w_names(p)$obs               # W component columns
                                    X_names = c(exposure, covars)         # predictor set for mia_ice()
                                    
                                    # mia_ice REQUIRES the outcome column to be named "Y" and the
                                    # Y_model LHS to be "Y". Rename on a local copy only.
                                    di_mia = di
                                    names(di_mia)[names(di_mia) == outcome] = "Y"
                                    
                                    
                                    # rebuild the outcome-model formula with LHS "Y", same RHS
                                    # terms as the gold model (keeps interactions), FULLY CROSSED
                                    # with the W block. 
                                    # ***Note: It's very important to include all C-W interactions since some DAGs, e.g., 1A, include
                                    #  those interactions! HOWEVER, the code below does NOT include W-W interactions, which matches
                                    #  all DAGs' DGMs as of 2026-07-22.
                                    rhs_terms = labels(terms(fo))         # e.g. "A","C","A:C"
                                    
                                    # X-part: the gold model's RHS as a single grouped term,
                                    # e.g. "(A + C + A:C)". Falls back to intercept-only if the
                                    # gold model has no RHS terms.
                                    x_part = if (length(rhs_terms) > 0)
                                      paste0("(", paste(rhs_terms, collapse = " + "), ")") else "1"
                                    
                                    # W-part: all observed W components as a single grouped term,
                                    # e.g. "(W01)" for |W|=1 or "(W1 + W2 + ... )" for a W block.
                                    w_part = paste0("(", paste(Wobs, collapse = " + "), ")")
                                    
                                    # Full cross: Y ~ (X terms) * (W terms). The "*" expands to all
                                    # main effects plus every X:W interaction (and X:X, W:W within
                                    # each group as already implied by rhs_terms / additive W).
                                    Y_form = as.formula(paste0("Y ~ ", x_part, " * ", w_part))
                                    # end of building the outcome-model formula

                                    
                                    # outer model: g_hat ~ (X predictors only), saturated.
                                    # RHS may reference ONLY X_names (mia_ice errors otherwise), so
                                    # it is built from the X's, NOT from rhs_terms and NOT with W.
                                    #   1 covar  -> g_hat ~ A * C   (saturated in binary A, C)
                                    #   0 covars -> g_hat ~ A
                                    outer_rhs  = paste(X_names, collapse = " * ")
                                    outer_form = as.formula( paste("g_hat ~", outer_rhs) )
                                    
                                    # contrast: exposure 1 vs 0, covars held at reference level 0
                                    ref = rep(0, length(covars))
                                    Xv1 = c(1, ref)
                                    Xv0 = c(0, ref)
                                    
                                    Y_type = if ( p$model == "logistic" ) "binary" else "continuous"
                                    
                                    fit = miapack::mia_ice(
                                      data          = di_mia,
                                      X_names       = X_names,
                                      X_values_1    = Xv1,
                                      X_values_2    = Xv0,
                                      contrast_type = "difference",
                                      Y_model       = Y_form,
                                      Y_type        = Y_type,
                                      outer_model   = outer_form
                                    )
                                    
                                    # point estimate = the exposure 1 vs 0 contrast
                                    # inthat = reference-level mean E0 (exposure 0, covars 0),
                                    # i.e. fit$mean_est_2 -- the "(Intercept)"-analogue level.
                                    if ( p$boot_reps_mia_ice == 0 ) {
                                      return( list( stats = data.frame(
                                        bhat   = fit$contrast_est,
                                        inthat = fit$mean_est_2
                                      ) ) )
                                    }
                                    
                                    # bootstrap CI via miapack::get_CI 
                                    # get_CI takes the FITTED mia object (not the modeling args)
                                    # and wraps boot / boot.ci. type = "bca" is the mia default.
                                    ci_obj = miapack::get_CI(
                                      mia_res = fit,
                                      n_boot  = p$boot_reps_mia_ice,
                                      type    = "bca",   
                                      conf    = 0.95
                                    )
                                    
                                    bhat_ci_row = ci_obj$ci_contrast[[4]]
                                    bhat_ci_lo  = bhat_ci_row[ length(bhat_ci_row) - 1 ]
                                    bhat_ci_hi  = bhat_ci_row[ length(bhat_ci_row) ]
                                    
                                    inthat_ci_row = ci_obj$ci_2[[4]]  # ci_2 because inthat = mean_est_2 (all predictors 0)
                                    inthat_ci_lo  = inthat_ci_row[ length(inthat_ci_row) - 1 ]
                                    inthat_ci_hi  = inthat_ci_row[ length(inthat_ci_row) ]
                                    
                                    return( list( stats = data.frame(
                                      bhat       = fit$contrast_est,
                                      bhat_lo    = bhat_ci_lo,
                                      bhat_hi    = bhat_ci_hi,
                                      bhat_width = bhat_ci_hi - bhat_ci_lo,
                                      
                                      inthat    = fit$mean_est_2,
                                      int_lo    = inthat_ci_lo,
                                      int_hi    = inthat_ci_hi,
                                      int_width = inthat_ci_hi - inthat_ci_lo
                                    ) ) )
                                    
                                    
                                  },
                                  .rep.res = rep.res )
        
        if (run.local == TRUE) srr(rep.res)
      }
      
      
      # FOR DEBUGGING
      cat("\n rep.res after running mia-pkg-ice")
      if (exists("rep.res")) srr(rep.res)
      
      
      
     # ~~ MIA-tmle -------------------------------------------------
      ## mu_MIA(x) = E[ E(Y | X = x, W, S, r_Y = 1) | X = x, S ],  S = {r_X = r_W = 1}
      ##
      ## Restrict to S, subset to the X = x stratum, call tmle() with A = NULL and
      ## Delta = r_Y. tmle's EY1 averages the targeted outcome regression over the
      ## empirical covariate distribution of whatever subset it is handed, which on
      ## the X = x subset is exactly p_hat(w | X = x, S) -- the outer measure the MIA
      ## functional integrates against. No reweighting needed.
      ##
      ## bhat   = mu_MIA(exposure = 1, covars = 0) - mu_MIA(exposure = 0, covars = 0)
      ## inthat = mu_MIA(exposure = 0, covars = 0)   <- reference level, matching the
      ##          mean_est_2 / ci_2 convention used for the miapack methods.

      
      rep.res = run_method_safe(
        method.label = c("mia-tmle"),
        method.fn = function(x) {
          
          # TMLE estimation of mu_MIA(x) at values xv of the X-variables
          # Do not try to move this fn to helper_IAI.R! It depends on locally scoped vars.
          mia_tmle_pt_est = function(xv) {
            
            keep = Reduce(`&`, lapply(seq_along(X_names),
                                      function(k) dS[[ X_names[k] ]] == xv[k]))
            idx = which(keep)
            
            # X is constant inside the stratum, so the adjustment set is W alone.
            # Note this sidesteps the X-by-W interaction trap that bites the
            # additive Y_model specification: within a stratum every X:W term is
            # collinear with the corresponding W main effect, so an additive-in-W
            # model here is the exact analogue of the fully crossed
            # Y ~ (A + C + A:C) * (W...) model used by mia-pkg-sp.
            cc_mean = function() {
              yo = Yv[idx][ rY[idx] == 1 ]
              list( psi = mean(yo), var = var(yo) / length(yo) )
            }
            
            Wd = dS[idx, Wobs, drop = FALSE]
            
            # drop no-variation columns BEFORE expansion: a single-level factor
            # makes model.matrix() error on contrasts
            Wd = Wd[, vapply(Wd, function(z) length(unique(z)) > 1L, logical(1)),
                    drop = FALSE]
            if ( ncol(Wd) == 0L ) return( cc_mean() )
            
            # Expand factors to numeric dummies HERE, so that tmle's internal
            #   W <- model.matrix(tempY ~ -1 + ., data = data.frame(tempY, W))
            # (tmle.R ~line 1720) is a no-op on the column names. Passing a factor
            # straight through lets tmle rename W01 -> W010/W011, after which a
            # hand-built Qform referencing "W01" dies with
            #   Error in eval(predvars, data, env) : object 'W01' not found
            Wd = stats::model.matrix( ~ ., data = Wd )[, -1, drop = FALSE]
            
            # a dummy can still be constant within a stratum
            Wd = Wd[, apply(Wd, 2, function(z) length(unique(z)) > 1L), drop = FALSE]
            if ( ncol(Wd) == 0L ) return( cc_mean() )
            
            # generic syntactic names: formula-safe, and guaranteed to survive
            # tmle's model.matrix pass unchanged since Wd is now numeric
            colnames(Wd) = paste0("W", seq_len(ncol(Wd)))
            
            # missingness model
            # Fitted HERE rather than handed to tmle via g.Deltaform. tmle's internal
            # call is
            #   estimateG(d = data.frame(Delta, Z=1, A, W[, retainW.Delta]), ...)
            # (tmle.R ~line 1898) and that subset carries no drop = FALSE, so when
            # exactly one W column is retained it collapses to a vector and
            # data.frame() names the column off the deparsed expression instead of
            # "W1" -- after which a g.Deltaform referencing W1 dies with
            #   Error in eval(predvars, data, env) : object 'W1' not found
            # Supplying pDelta1 skips that path entirely. With Z = NULL it must be
            # n x 2, [P(Delta=1|A=0,W), P(Delta=1|A=1,W)]; A is constant here so the
            # two columns are identical. tmle still applies its own truncation
            # downstream at line 1901, so nothing is lost by precomputing.
            pD = if ( all(rY[idx] == 1) ) {
              matrix(1, nrow = length(idx), ncol = 2)
            } else {
              gfit   = stats::glm( rY[idx] ~ ., data = as.data.frame(Wd),
                                   family = stats::binomial() )
              pi_hat = stats::predict(gfit, type = "response")
              cbind(pi_hat, pi_hat)
            }  # end of mu_at fn
            
            # outcome model
            # Q is safe to pass as a formula: its data frame is
            # data.frame(Y, Z, A, W, Delta) with the FULL W, so it never hits the
            # drop-to-vector path above. collapse = " " is load-bearing -- deparse()
            # returns a character VECTOR once the formula exceeds width.cutoff = 60
            # chars, which "Y ~ A + W1 + ... + W10" does, and tmle would then pass
            # that multi-element vector to formula() (deprecated).
            Q_form = paste( deparse( reformulate(c("A", colnames(Wd)), response = "Y") ),
                            collapse = " " )
            
            fit = tmle::tmle(
              Y            = Yv[idx],
              A            = NULL,           # no treatment => EY1 is the target
              W            = Wd,
              Delta        = rY[idx],
              pDelta1      = pD,             # missingness model supplied directly
              family       = fam,
              Qform        = Q_form,
              prescreenW.g = FALSE,          # keep the whole W block in the g model
              verbose      = FALSE,
              #cvQinit = FALSE  # ****2026-07-27 - added to prevent tmle from crashing
              
              # 2026-07-28 - NOTE: The next 2 arguments patch a bug in tmle(): 
              #  throws "subscript out of bounds" whenever cvQinit = TRUE and the input has fewer rows than V.Q,
              #  because estimateQ builds its fold list via split(sample(1:n.id), rep(1:V, length = n.id)). 
              # That returns only n.id folds when n.id < V — then indexes id.split[[v]] over the full 1:V.
              cvQinit = TRUE,
              V.Q = max(2, min(10, floor(length(idx)/5)))
            )
            
            # var.psi is the plug-in EIF variance, var(IC)/n, where
            #   IC = rY/pi(x,W) * {Y - b(x,W)} + b(x,W) - psi
            # already back-transformed to the original Y scale.
            list( psi = fit$estimates$EY1$psi,
                  var = fit$estimates$EY1$var.psi )
          }
          
          # parse the gold model into outcome + predictors, same as the mia-pkg-sp
          # block so the two methods are guaranteed to target the same contrast
          fo       = as.formula(form_string)      # e.g. B ~ A * C
          outcome  = all.vars(fo)[1]              # LHS, e.g. "B"
          exposure = coef_of_interest             # e.g. "A"
          rhs_vars = all.vars(fo)[-1]             # main-effect vars on RHS
          covars   = setdiff(rhs_vars, exposure)  # analysis covars X \ exposure
          
          Wobs    = w_names(p)$obs                # W component columns
          X_names = c(exposure, covars)           # the conditioning set X
          
          # restrict to S = {r_X = r_W = 1}
          S_rows = stats::complete.cases( di[, c(X_names, Wobs), drop = FALSE] )
          dS     = di[S_rows, , drop = FALSE]
          
          rY = as.integer( !is.na(dS[[outcome]]) )
          
          # tmle() will not tolerate NA in Y even on Delta == 0 rows: Qbounds
          # defaults to range(Y), which would go NA and poison the fit. The
          # placeholder is arbitrary -- those rows enter only via the missingness
          # model -- but it must be in range.
          Yv = dS[[outcome]]
          Yv[rY == 0] = 0
          
          fam = if ( p$model == "logistic" ) "binomial" else "gaussian"
          
          # check that X is discrete, as it must be for this implementation
          n_lev = vapply(X_names, function(v) length(unique(dS[[v]])), integer(1))
          if ( any(n_lev > 10) ) {
            stop("mia-tmle requires discrete X; ",
                 paste0(X_names[n_lev > 10], " has ", n_lev[n_lev > 10], " levels",
                        collapse = "; "),
                 ". Use mia() / mia_ice() for continuous X.")
          }

          
          # contrast: exposure 1 vs 0, covars held at reference 0
          ref = rep(0, length(covars))
          m1  = mia_tmle_pt_est( c(1, ref) )
          m0  = mia_tmle_pt_est( c(0, ref) )
          
          bhat   = m1$psi - m0$psi
          inthat = m0$psi
          
          # The two strata are disjoint sets of rows and their nuisance models are
          # fit separately, so the estimates are independent and the variances add
          # with no covariance term.
          v_b = m1$var + m0$var
          v_i = m0$var
          
          if ( p$calculate_tmle_CIs == FALSE ) {
            return( list( stats = data.frame(
              bhat   = bhat,
              inthat = inthat
            ) ) )
          }
          
          # influence-curve based CIs
          z = stats::qnorm(0.975)
          
          return( list( stats = data.frame(
            bhat       = bhat,
            bhat_lo    = bhat - z * sqrt(v_b),
            bhat_hi    = bhat + z * sqrt(v_b),
            bhat_width = 2 * z * sqrt(v_b),
            
            inthat    = inthat,
            int_lo    = inthat - z * sqrt(v_i),
            int_hi    = inthat + z * sqrt(v_i),
            int_width = 2 * z * sqrt(v_i)
          ) ) )
        },
        .rep.res = rep.res )
      
      if (run.local == TRUE) srr(rep.res)

      # ~ Add Scen Params and Sanity Checks --------------------------------------
      
      # add in scenario parameters
      # do NOT use rbind here; bind_cols accommodates possibility that some methods' rep.res
      #  have more columns than others
      rep.res = p %>% bind_cols( rep.res )
      
      # these don't come from p because they are from sim_data instead
      rep.res$coef_of_interest = coef_of_interest
      rep.res$beta = beta
      
      rep.res$form_string = form_string
      rep.res$gold_form_string = gold_form_string
      
      # add more info
      rep.res = rep.res %>% add_column( rep.name = i, .before = 1 )
      rep.res = rep.res %>% add_column( scen.name = scen, .before = 1 )
      if (run.local == FALSE ) rep.res = rep.res %>% add_column( job.name = jobname, .before = 1 )
  
      
      # return this rep's results as the last expression of the foreach body
      rep.res
      
    }  # END foreach %dopar% body
  })  # END system.time({
  
  if ( exists("rs_all_scens") ) rs_all_scens = rs_all_scens %>% bind_rows(rs) else rs_all_scens = rs

  
}  # END FOR-LOOP to run multiple scens locally





if ( run.local == TRUE ) {
  
  #View(rs_all_scens)
  
  dim(rs_all_scens)
  
  # look for NA CIs
  rs_all_scens %>% filter(method == "mia-pkg-ice") %>%
    summarise(mean_NA = meanNA(bhat_lo))
  
  mean( is.na(rs_all_scens$bhat_lo[ rs_all_scens$method == "mia-pkg-ice"]) )
  
  
  # fill in true beta
  beta_emp = rs_all_scens %>% filter(method == "gold") %>%
    group_by(scen.name) %>%
    summarise(beta = meanNA(bhat)) 
  as.data.frame(beta_emp)
  
  rs_all_scens = rs_all_scens %>% rowwise() %>%
    mutate( beta = ifelse( !is.na(beta),
                           beta,
                           beta_emp$beta[ beta_emp$scen.name == scen.name ] ) )
  
  
  t = rs_all_scens %>% group_by(dag_name, method) %>%
    summarise( 
      reps = n(),
      Bhat = meanNA(bhat),
      BhatBias = meanNA(bhat - beta),
      BhatLo = meanNA(bhat_lo),
      BhatHi = meanNA(bhat_hi),
      BhatRMSE = sqrt( meanNA( (bhat - beta)^2 ) ),
      BhatCover = meanNA( covers(truth = beta,
                                 lo = bhat_lo,
                                 hi = bhat_hi) ) ) %>%
    # EYpred = meanNA(EY_prediction) ) %>%
    arrange() %>%
    mutate_if(is.numeric, function(x) round(x,2)) 
  
  as.data.frame(t)
  
  # # with E[B |A,C]
  # t = rs_all_scens %>% group_by(method) %>%
  #   summarise( 
  #     reps = n(),
  #     Bhat = meanNA(bhat),
  #     BhatBias = meanNA(bhat - beta),
  #     BhatLo = meanNA(bhat_lo),
  #     BhatHi = meanNA(bhat_hi),
  #     BhatRMSE = sqrt( meanNA( (bhat - beta)^2 ) ),
  #     BhatCover = meanNA( covers(truth = beta,
  #                                lo = bhat_lo,
  #                                hi = bhat_hi) ),
  #     Ehat_B_a1c0 = meanNA(Ehat_B_a1c0),
  #     E_B_a1c0 = meanNA(E_B_a1c0)) %>%
  #   arrange() %>%
  #   mutate_if(is.numeric, function(x) round(x,2)) 
  # 
  # as.data.frame(t)
  
  # setwd(data.dir)
  # fwrite( rs_all_scens,
  #         paste( "stitched_local.csv", sep = "" ) )
}




# ~ QUICK RESULTS SUMMARY ---------------------------------------------------

if ( run.local == TRUE ) {
  rs %>%
    dplyr::select(method, bhat, bhat_width, bhat_covers) %>%
    
    group_by(method) %>%
    summarise_if(is.numeric, function(x) round( meanNA(x), 2 ) )
  
  any(is.na(rs$bhat))
}


# ~ WRITE LONG RESULTS ------------------------------
if ( run.local == FALSE ) {
  cat("\n *** FLAG 1: About to write long results")
  setwd("/home/groups/manishad/IAI/long_results")
  fwrite( rs, paste( "long_results", jobname, ".csv", sep="_" ) )
  cat("\n *** FLAG 3: Done writing long results")
}